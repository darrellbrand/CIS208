package com.example.dj.mymustangmaintenanceapp;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;


/**
 * Created by DJ on 4/17/2016.
 */
public class InputFragment extends Fragment {


    private static final String COOLANT = "COOLANT_TEXT";
    private static final String OIL_CHANGE = "OIL_CHANGE_TEXT";
    private static final String SPARK_PLUG = "SPARK_PLUG_TEXT";



    private EditText mOilChange;
    private EditText mCoolant;
    private EditText mSparkPlug;
    private Button   mButton;
    private OnStatusSelected mStatusSelected;
    private Switch mTrackSwitch;

    private int   oil_int;
    private int   coolant_int;
    private int   spark_plug_int;
    private boolean track_bool;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){



      View v = inflater.inflate(R.layout.input_fragment, container, false);


        mOilChange = (EditText) v.findViewById(R.id.oil_change_text);

        mCoolant = (EditText) v.findViewById(R.id.coolant_text);

        mSparkPlug = (EditText) v.findViewById(R.id.spark_plug_text);

        mButton = (Button) v.findViewById(R.id.status_button);

        mTrackSwitch = (Switch)v.findViewById(R.id.track_switch);


        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                oil_int = Integer.parseInt(mOilChange.getText().toString());
                coolant_int = Integer.parseInt(mCoolant.getText().toString());
                spark_plug_int =  Integer.parseInt(mSparkPlug.getText().toString());
                track_bool = mTrackSwitch.isChecked();

                mStatusSelected.changeStatus(oil_int,coolant_int,spark_plug_int,track_bool);



            }
        });



           return v;

    }



    public interface OnStatusSelected{


             void changeStatus(int oil_change,int coolant, int spark_plug,boolean track_switch);

    }



    @Override
    public void onAttach(Context context){


        super.onAttach(context);

        try{ mStatusSelected = (OnStatusSelected) context;}
       catch (ClassCastException e) {throw new ClassCastException(context.toString()+"must implement OnStatusSelected");}



    }





}

