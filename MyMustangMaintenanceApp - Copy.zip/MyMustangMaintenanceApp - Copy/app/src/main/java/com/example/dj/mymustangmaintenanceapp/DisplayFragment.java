package com.example.dj.mymustangmaintenanceapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

/**
 * Created by DJ on 4/17/2016.
 */


public class DisplayFragment extends Fragment {


    private int oil;
    private int coolant;
    private int spark;
    private ProgressBar mOil_bar;
    private ProgressBar mCoolant_bar;
    private ProgressBar mSpark_bar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
       View v =inflater.inflate(R.layout.display_fragment,container,false);

        mOil_bar = (ProgressBar)v.findViewById(R.id.oil_bar);
        mCoolant_bar =(ProgressBar)v.findViewById(R.id.coolant_bar);
        mSpark_bar=(ProgressBar)v.findViewById(R.id.spark_bar);

        return v;

    }
}

